# tts_process.py
import pyttsx3
import sys

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty("rate", 177)
engine.setProperty('voice', voices[0].id)

text = " ".join(sys.argv[1:])  # get text from command line arguments
engine.say(text)
engine.runAndWait()
